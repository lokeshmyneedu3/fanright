# mailbox
Messages plugin for Oxwall. Unified messaging plugin for private on-site communication.
